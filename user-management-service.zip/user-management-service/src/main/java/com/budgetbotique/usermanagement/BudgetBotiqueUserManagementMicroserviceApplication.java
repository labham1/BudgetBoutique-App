package com.budgetbotique.usermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BudgetBotiqueUserManagementMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BudgetBotiqueUserManagementMicroserviceApplication.class, args);
	}

}
